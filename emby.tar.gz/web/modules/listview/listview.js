define(["playbackManager", "itemContextMenu", "dom", "cardBuilder", "itemShortcuts", "itemHelper", "mediaInfo", "indicators", "connectionManager", "layoutManager", "globalize", "datetime", "apphost", "imageLoader", "focusManager", "emby-playstatebutton", "emby-ratingbutton", "css!./listview", "embyProgressBarStyle", "emby-linkbutton"], function (playbackManager, itemContextMenu, dom, cardBuilder, itemShortcuts, itemHelper, mediaInfo, indicators, connectionManager, layoutManager, globalize, datetime, appHost, imageLoader, focusManager, EmbyPlaystateButton, EmbyRatingButton) {
    "use strict";
    var supportsNativeLazyLoading = "loading" in HTMLImageElement.prototype;
    function getTextLinesHtml(textlines, isLargeStyle) {
        for (var html = "", isFirst = !0, cssClass = "listItemBodyText listItemBodyText-nowrap", i = 0, length = textlines.length; i < length; i++) {
            var text = textlines[i];
            text && (html += isFirst ? isLargeStyle ? '<h3 class="' + cssClass + '">' : '<div class="' + cssClass + '">' : '<div class="' + cssClass + ' listItemBodyText-secondary">', html += text, html += isFirst && isLargeStyle ? "</h3>" : "</div>", isFirst = !1)
        }
        return html
    }
    function getId(item) {
        return item.Id
    }
    function getListItemHtml(item, index, options) {
        var enableOverview = options.enableOverview,
        enableSideMediaInfo = options.enableSideMediaInfo,
        isLargeStyle = options.isLargeStyle,
        enableContentWrapper = options.enableContentWrapper,
        tagName = options.tagName,
        action = options.action,
        html = "",
        downloadWidth = 80;
        isLargeStyle && (downloadWidth = 600);
        var hoverPlayButtonRequested = !layoutManager.tv && !1 !== options.hoverPlayButton && !options.imagePlayButton,
        enableHoverPlayButton = hoverPlayButtonRequested && playbackManager.canPlay(item);
        enableContentWrapper && (html += '<div class="' + options.contentWrapperClass + '">');
        var serverId = item.ServerId,
        apiClient = serverId ? connectionManager.getApiClient(serverId) : null;
        options.multiSelect && (html += '<label title="' + options.multiSelectTitle + '" data-action="multiselect" class="chkListItemSelectContainer chkItemSelectContainer itemAction emby-checkbox-label"><input tabindex="-1" class="chkListItemSelect chkItemSelect emby-checkbox emby-checkbox-notext" is="emby-checkbox" type="checkbox" data-classes="true" /><span class="checkboxLabel chkListItemSelect-checkboxLabel"></span></label>');
        var checkbox,
        imageItem,
        imgUrlInfo,
        imgUrl,
        imageContainerClass,
        imageClass,
        playOnImageClick,
        imageAction,
        color,
        styleRules,
        progressHtml,
        itemShape,
        aspectInfo,
        coveredImageClass,
        icon,
        indicatorsHtml,
        indexNumberClass,
        itemType = item.Type,
        fieldMap = options.fieldMap;
        fieldMap.ChannelDisabledCheckbox && (checkbox = options.channelCheckbox, item.Disabled || (checkbox = checkbox.replace('type="checkbox"', 'type="checkbox" checked')), html += checkbox),
        !1 !== options.image && (imageItem = options.showCurrentProgramImage ? item.CurrentProgram || item : item.ProgramInfo || item, imgUrl = (imgUrlInfo = cardBuilder.getImageUrl(imageItem, apiClient, {
                        width: downloadWidth,
                        showChannelLogo: "channel" === options.imageSource
                    })).imgUrl, imageContainerClass = options.imageContainerClass, imageClass = "listItemImage", isLargeStyle && (imageClass += " listItemImage-large"), options.roundImage && (imageClass += " listItemImage-round", imgUrl || (imageContainerClass += " listItemImageContainer-round")), playOnImageClick = options.imagePlayButton && !layoutManager.tv, options.playlistItemId && options.playlistItemId === item.PlaylistItemId && (imageContainerClass += " playlistIndexIndicatorImage"), imageAction = playOnImageClick ? "resume" : action, imgUrl && !options.defaultBackground || (imageContainerClass += " defaultCardBackground defaultCardBackground0"), styleRules = [], (color = "Error" === item.Severity || "Fatal" === item.Severity || "Warn" === item.Severity ? "background-color:#cc0000;color:#fff;" : "") && styleRules.push(color), styleRules.push("aspect-ratio:" + options.aspectInfo.aspectCss), html += '<div data-action="' + imageAction + '" class="' + imageContainerClass + '"' + (styleRules.length ? ' style="' + styleRules.join(";") + '"' : "") + ">", progressHtml = indicators.getProgressBarHtml(item, {
                    containerClass: "listItemProgressBar"
                }), imgUrl ? (itemShape = imageLoader.getShape([item], options) || "square", aspectInfo = imageLoader.getAspectFromShape(itemShape, options), imageClass += " listItemImage-" + itemShape, (coveredImageClass = imageLoader.getCoveredImageClass(imageItem, imgUrlInfo.aspect, aspectInfo.aspect)) && (imageClass += coveredImageClass), 2 === options.lazy ? html += '<div class="' + imageClass + '" style="aspect-ratio:' + aspectInfo.aspectCss + ";background-image:url(" + imgUrl + ');">' : html += supportsNativeLazyLoading ? '<div class="' + imageClass + '" loading="lazy" style="aspect-ratio:' + aspectInfo.aspectCss + ";background-image:url(" + imgUrl + ');">' : '<div class="' + imageClass + ' lazy" style="aspect-ratio:' + aspectInfo.aspectCss + ";background-image:url(" + imgUrl + ');">', progressHtml && (html += progressHtml), html += "</div>") : ((icon = item.Icon || cardBuilder.getDefaultIcon(item)) && (html += '<i class="' + options.iconClass + '">' + icon + "</i>"), progressHtml && (html += progressHtml)), (indicatorsHtml = indicators.getPlayedIndicatorHtml(item, options.indicatorClass)) && (html += indicatorsHtml), enableHoverPlayButton ? html += '<button tabindex="-1" type="button" is="paper-icon-button-light" class="listItemOverlayButton-hover listItemOverlayButton-imagehover itemAction" data-action="' + (item.IsFolder ? "resume" : options.playAction || "play") + '"><i class="md-icon listItemOverlayButtonIcon">&#xE037;</i></button>' : playOnImageClick && (html += '<button title="' + globalize.translate("Play") + '"  aria-label="' + globalize.translate("Play") + '"type="button" is="paper-icon-button-light" class="listItemImageButton itemAction" data-action="resume"><i class="md-icon listItemImageButton-icon">&#xE037;</i></button>'), html += "</div>"),
        options.showIndexNumberLeft && (indexNumberClass = "listItem-indexnumberleft secondaryText", hoverPlayButtonRequested && (indexNumberClass += " listItem-indexnumberleft-withhoverbutton"), html += '<div class="' + indexNumberClass + '">', null == item.IndexNumber ? html += "&nbsp;" : html += item.IndexNumber, enableHoverPlayButton && (html += '<button tabindex="-1" type="button" is="paper-icon-button-light" class="listItemOverlayButton-hover itemAction" data-action="' + (item.IsFolder ? "resume" : options.playAction || "play") + '"><i class="md-icon listItemOverlayButtonIcon">&#xE037;</i></button>'), enableHoverPlayButton = !1, html += "</div>"),
        html += "<" + options.listItemBodyTagName + ' class="' + options.listItemBodyClassName + '">';
        var listItemBodyTextTagName = options.isLargeStyle ? "h3" : "div",
        listItemBodyTextOpen = "<" + listItemBodyTextTagName + ' class="listItemBodyText listItemBodyText-nowrap">',
        listItemBodyTextClose = "</" + listItemBodyTextTagName + ">",
        secondaryListItemBodyTextOpen = '<div class="listItemBodyText listItemBodyText-secondary listItemBodyText-nowrap">';
        options.showProgramDateTime && (html += listItemBodyTextOpen + datetime.toLocaleString(datetime.parseISO8601Date(item.StartDate), {
                weekday: "long",
                month: "short",
                day: "numeric",
                hour: "numeric",
                minute: "2-digit"
            }) + listItemBodyTextClose, listItemBodyTextTagName = "div", listItemBodyTextOpen = secondaryListItemBodyTextOpen, listItemBodyTextClose = "</div>"),
        options.showAccessToken && (html += listItemBodyTextOpen + item.AccessToken + " - " + item.AppName + listItemBodyTextClose, listItemBodyTextTagName = "div", listItemBodyTextOpen = secondaryListItemBodyTextOpen, listItemBodyTextClose = "</div>"),
        options.showChannel && item.ChannelName && (html += listItemBodyTextOpen + dom.htmlEncode(item.ChannelName) + listItemBodyTextClose, listItemBodyTextTagName = "div", listItemBodyTextOpen = secondaryListItemBodyTextOpen, listItemBodyTextClose = "</div>");
        var parentTitle = null;
        options.showParentTitle && ("Episode" === itemType ? parentTitle = item.SeriesName : (item.IsSeries || item.EpisodeTitle && item.Name) && (parentTitle = item.Name));
        var displayName = itemHelper.getDisplayName(item, {
                includeParentInfo: options.includeParentInfoInTitle,
                includeIndexNumber: (!item.SupportsResume || "Audio" !== item.Type) && null
            });
        options.showIndexNumber && null != item.IndexNumber && (displayName = item.IndexNumber + ". " + displayName),
        options.showParentTitle && parentTitle && (html += listItemBodyTextOpen + (parentTitle ? dom.htmlEncode(parentTitle) : "") + listItemBodyTextClose, listItemBodyTextTagName = "div", listItemBodyTextOpen = secondaryListItemBodyTextOpen, listItemBodyTextClose = "</div>"),
        options.showLogLine && (html += listItemBodyTextOpen + dom.htmlEncode(item) + listItemBodyTextClose, listItemBodyTextTagName = "div", listItemBodyTextOpen = secondaryListItemBodyTextOpen, listItemBodyTextClose = "</div>");
        var mappingInfo,
        guideSourceInfo,
        nameRendered = !1;
        fieldMap.ChannelNameAndNumber && (html += listItemBodyTextOpen, html += '<div class="flex align-items-center">', item.ChannelNumber && (html += item.ChannelNumber + " "), html += item.Name + "</div>" + listItemBodyTextClose, listItemBodyTextOpen = secondaryListItemBodyTextOpen, listItemBodyTextClose = "</div>", nameRendered = !0),
        fieldMap.MappedChannelInfo && (html += listItemBodyTextOpen, item.ListingsChannelName && (mappingInfo = item.ListingsChannelName, item.ListingsChannelNumber && (mappingInfo = item.ListingsChannelNumber + " " + mappingInfo), item.AffiliateCallSign && (mappingInfo += " - " + item.AffiliateCallSign), (guideSourceInfo = item.ListingsId || item.ListingsPath) && (mappingInfo += " - " + dom.htmlEncode(guideSourceInfo)), mappingInfo = globalize.translate("MappedToValue", mappingInfo)), html += mappingInfo || globalize.translate("NotMappedToGuideData"), html += listItemBodyTextClose, listItemBodyTextTagName = "div", listItemBodyTextOpen = secondaryListItemBodyTextOpen, listItemBodyTextClose = "</div>"),
        options.mediaInfoWithTitle ? (html += "<" + listItemBodyTextTagName + ' class="listItemBodyText listItemBodyText-withmediainfo listItemBodyText-nowrap listItemBodyText-secondary flex align-items-center flex-direction-row">', html += mediaInfo.getPrimaryMediaInfoHtml(item, {
                episodeTitle: !1,
                originalAirDate: !1,
                subtitles: !1,
                endsAt: !1
            }), html += dom.htmlEncode(displayName), html += listItemBodyTextClose, listItemBodyTextTagName = "div", listItemBodyTextOpen = secondaryListItemBodyTextOpen, listItemBodyTextClose = "</div>") : displayName && !nameRendered && (html += listItemBodyTextOpen + displayName + listItemBodyTextClose, listItemBodyTextOpen = secondaryListItemBodyTextOpen, listItemBodyTextClose = "</div>");
        var containerAlbumArtistIds,
        showArtist = !0 === options.artist,
        artistItems = "MusicAlbum" === item.Type ? item.AlbumArtists : item.ArtistItems;
        showArtist || !1 === options.artist || (containerAlbumArtistIds = options.containerAlbumArtistIds, artistItems && artistItems.length && !(1 < artistItems.length) && containerAlbumArtistIds && 1 === containerAlbumArtistIds.length && -1 !== containerAlbumArtistIds.indexOf(artistItems[0].Id) || (showArtist = !0)),
        showArtist && artistItems && (html += listItemBodyTextOpen + (artistItems.map(function (a) {
                    return a.Type = "MusicArtist",
                    a.IsFolder = !0,
                    function (options, item, text, serverId, parentId, isSameItemAsCard) {
                        if (text = text || itemHelper.getDisplayName(item), layoutManager.tv)
                            return dom.htmlEncode(text);
                        if (!1 === options.textLinks)
                            return dom.htmlEncode(text);
                        var html = '<button title="' + (text = dom.htmlEncode(text)) + '" title="' + text + '" ' + (isSameItemAsCard ? "" : itemShortcuts.getShortcutAttributesHtml(item, {
                                    serverId: serverId,
                                    parentId: parentId
                                })) + ' type="button"' + (options.draggable && options.draggableSubItems && !isSameItemAsCard ? ' draggable="true"' : "") + ' class="itemAction textActionButton listItem-textActionButton emby-button button-link" data-action="link">';
                        return html += text,
                        html += "</button>"
                    }
                    (options, a, null, item.ServerId)
                }).join(", ") || "") + listItemBodyTextClose, listItemBodyTextOpen = secondaryListItemBodyTextOpen, listItemBodyTextClose = "</div>"),
        "Game" === itemType ? (html += listItemBodyTextOpen + dom.htmlEncode(item.GameSystem) + listItemBodyTextClose, listItemBodyTextOpen = secondaryListItemBodyTextOpen, listItemBodyTextClose = "</div>") : "TvChannel" === itemType && item.CurrentProgram && (html += listItemBodyTextOpen + dom.htmlEncode(itemHelper.getDisplayName(item.CurrentProgram)) + listItemBodyTextClose, listItemBodyTextOpen = secondaryListItemBodyTextOpen, listItemBodyTextClose = "</div>"),
        options.showDateCreated && (html += listItemBodyTextOpen + datetime.toLocaleString(datetime.parseISO8601Date(item.DateCreated, !0)) + listItemBodyTextClose, listItemBodyTextOpen = secondaryListItemBodyTextOpen, listItemBodyTextClose = "</div>"),
        fieldMap.ChannelNumber && (html += listItemBodyTextOpen + (item.ChannelNumber || "") + listItemBodyTextClose, listItemBodyTextOpen = secondaryListItemBodyTextOpen, listItemBodyTextClose = "</div>"),
        fieldMap.DateModified && (html += listItemBodyTextOpen + datetime.toLocaleString(datetime.parseISO8601Date(item.DateModified, !0)) + listItemBodyTextClose, listItemBodyTextOpen = secondaryListItemBodyTextOpen, listItemBodyTextClose = "</div>"),
        options.showDate && (html += listItemBodyTextOpen + datetime.toLocaleString(datetime.parseISO8601Date(item.Date, !0)) + listItemBodyTextClose, listItemBodyTextOpen = secondaryListItemBodyTextOpen, listItemBodyTextClose = "</div>"),
        options.showShortOverview && (html += listItemBodyTextOpen + (item.ShortOverview ? dom.htmlEncode(item.ShortOverview) : "&nbsp;") + listItemBodyTextClose, listItemBodyTextOpen = secondaryListItemBodyTextOpen, listItemBodyTextClose = "</div>");
        var sideMediaInfo,
        userData,
        textlines = [];
        if (fieldMap.MediaStreamInfo && mediaInfo.pushMediaStreamLines(item, options, textlines, cardBuilder.getDefaultIcon(item)), html += getTextLinesHtml(textlines, isLargeStyle), !1 !== options.mediaInfo && (enableSideMediaInfo || options.mediaInfoWithTitle || (html += '<div class="listItemMediaInfo listItemBodyText listItemBodyText-secondary listItemBodyText-nowrap">' + mediaInfo.getPrimaryMediaInfoHtml(item, {
                        episodeTitle: !1,
                        originalAirDate: !1,
                        subtitles: !1,
                        endsAt: !1
                    }) + "</div>")), enableOverview && (html += '<div class="' + options.topOverviewClassName + '">', html += item.Overview ? dom.htmlEncode(item.Overview) : "", html += "</div>"), html += "</" + options.listItemBodyTagName + ">", !1 !== options.mediaInfo && (!enableSideMediaInfo || (sideMediaInfo = mediaInfo.getPrimaryMediaInfoHtml(item, {
                            year: !1,
                            container: !1,
                            episodeTitle: !1,
                            criticRating: !1,
                            endsAt: !1
                        })) && (html += '<div class="listItemMediaInfo secondaryText">' + sideMediaInfo + "</div>")), options.recordButton || "Timer" !== itemType && "Program" !== itemType || (html += indicators.getTimerIndicator(item).replace("indicatorIcon", "indicatorIcon listItemAside")), options.clickEntireItem || (options.addToListButton && (html += '<button title="' + globalize.translate("HeaderAddToPlaylist") + '" aria-label="' + globalize.translate("HeaderAddToPlaylist") + '" type="button" is="paper-icon-button-light" class="listItemButton itemAction" data-action="addtoplaylist"><i class="md-icon">&#xE03B;</i></button>'), options.openInNewWindowButton && appHost.supports("targetblank") && (html += '<a title="' + globalize.translate("HeaderOpenInNewWindow") + '" aria-label="' + globalize.translate("HeaderOpenInNewWindow") + '" type="button" is="emby-linkbutton" href="' + apiClient.getLogDownloadUrl(item) + '" target="_blank" class="paper-icon-button-light listItemButton itemAction" data-action="default"><i class="md-icon">open_in_new</i></a>'), options.downloadButton && (html += '<button title="' + globalize.translate("Download") + '" aria-label="' + globalize.translate("Download") + '" type="button" is="paper-icon-button-light" class="listItemButton itemAction" data-action="download"><i class="md-icon">download</i></button>'), options.contextMenu && !1 !== options.moreButton && itemContextMenu.supportsContextMenu(item) && (html += '<button title="' + globalize.translate("More") + '" aria-label="' + globalize.translate("More") + '" type="button" is="paper-icon-button-light" class="listItemButton listItemContextMenuButton itemAction" data-action="menu"><i class="md-icon">&#xE5D3;</i></button>'), options.infoButton && (html += '<button title="' + globalize.translate("Overview") + '" aria-label="' + globalize.translate("Overview") + '" type="button" is="paper-icon-button-light" class="listItemButton itemAction" data-action="link"><i class="md-icon">&#xE88F;</i></button>'), options.deleteButton && (html += '<button title="' + globalize.translate("Delete") + '" aria-label="' + globalize.translate("Delete") + '" type="button" is="paper-icon-button-light" class="listItemButton itemAction" data-action="delete"><i class="md-icon">delete</i></button>'), options.overviewButton && item.Overview && (html += '<button title="' + globalize.translate("Overview") + '" aria-label="' + globalize.translate("Overview") + '" type="button" is="paper-icon-button-light" class="listItemButton itemAction" data-action="overview"><i class="md-icon">&#xE88F;</i></button>'), options.rightButtons && (html += function (options) {
                    for (var html = "", i = 0, length = options.rightButtons.length; i < length; i++) {
                        var button = options.rightButtons[i];
                        html += '<button type="button" is="paper-icon-button-light" class="listItemButton itemAction" data-action="custom" data-customaction="' + button.id + '" title="' + button.title + '" aria-label="' + button.title + '"><i class="md-icon">' + button.icon + "</i></button>"
                    }
                    return html
                }
                    (options)), !1 !== options.enableUserDataButtons && (userData = item.UserData || {}, itemHelper.canMarkPlayed(item) && (html += EmbyPlaystateButton.getHtml(userData.Played, "listViewUserDataButton listItemButton paper-icon-button-light")), itemHelper.canRate(item) && (html += EmbyRatingButton.getHtml(userData.IsFavorite, "listViewUserDataButton listItemButton paper-icon-button-light"))), options.dragHandle && (html += '<i class="listViewDragHandle dragHandle md-icon listItemIcon listItemIcon-transparent">&#xE25D;</i>')), enableContentWrapper && (html += "</div>", enableOverview && (html += '<div class="' + options.bottomOverviewClassName + '">', html += item.Overview ? dom.htmlEncode(item.Overview) : "", html += "</div>")), options.listItemParts) {
            var attributes = itemShortcuts.getShortcutAttributes(item, options);
            return action && attributes.push({
                name: "data-action",
                value: action
            }),
            options.isVirtualList || attributes.push({
                name: "data-index",
                value: index
            }), {
                attributes: attributes,
                html: html
            }
        }
        var dataAttributes = itemShortcuts.getShortcutAttributesHtml(item, options);
        action && (dataAttributes += ' data-action="' + action + '"'),
        options.isVirtualList || (dataAttributes += ' data-index="' + index + '"');
        var fixedAttributes = options.fixedAttributes;
        return fixedAttributes && (dataAttributes += " " + fixedAttributes),
        "<" + tagName + ' class="' + options.className + '"' + dataAttributes + ">" + html + "</" + tagName + ">"
    }
    function setListOptions(items, options) {
        options.isListItem = !0,
        options.enableContentWrapper = !layoutManager.tv,
        options.contentWrapperClass = "listItem-content",
        layoutManager.tv || (options.contentWrapperClass += " listItemContent-touchzoom"),
        options.containerAlbumArtistIds = (options.containerAlbumArtists || []).map(getId),
        options.enableSideMediaInfo = null == options.enableSideMediaInfo || options.enableSideMediaInfo,
        options.clickEntireItem = !!layoutManager.tv || !(options.mediaInfo || options.moreButton || options.enableUserDataButtons || options.addToListButton || options.enableSideMediaInfo || options.enableOverview),
        options.isLargeStyle = "large" === options.imageSize,
        options.action = options.action || "link",
        options.tagName = options.clickEntireItem ? "button" : "div",
        options.listItemBodyTagName = "div",
        options.multiSelectTitle = globalize.translate("MultiSelect"),
        options.multiSelect = !1 !== options.multiSelect && !layoutManager.tv,
        options.contextMenu = !1 !== options.contextMenu,
        options.enableUserData = !1 !== options.enableUserData,
        options.isLargeStyle ? options.indicatorClass = "listItemIndicator listItem" : options.indicatorClass = "listItemIndicator listItemIndicator-mini listItem",
        options.fields || (options.fields = [], options.fields.push("Name"));
        for (var fieldMap = {}, i = 0, length = options.fields.length; i < length; i++)
            fieldMap[options.fields[i]] = !0;
        options.fieldMap = fieldMap;
        var cssClass = "listItem";
        (options.border || !1 !== options.highlight && !layoutManager.tv) && (cssClass += " listItem-border"),
        options.clickEntireItem && (cssClass += " itemAction"),
        "div" === options.tagName ? (cssClass += " focusable", options.addTabIndex = !0) : "button" === options.tagName && (cssClass += " listItem-button"),
        "none" === options.action && !options.clickEntireItem || (cssClass += " listItemCursor"),
        layoutManager.tv ? cssClass += " listItem-focusscale" : cssClass += " listItem-hoverable",
        layoutManager.tv || (options.draggable = !1 !== options.draggable, options.draggableSubItems = options.draggable && !1 !== options.draggableSubItems),
        options.isLargeStyle && (cssClass += " listItem-largeImage"),
        options.enableContentWrapper && (cssClass += " listItem-withContentWrapper"),
        !1 === options.verticalPadding && (cssClass += " listItem-noverticalpadding"),
        options.itemClass && (cssClass += " " + options.itemClass),
        options.dragHandle && options.draggable ? cssClass += " drop-target ordered-drop-target-y" : options.dropTarget && !layoutManager.tv && (cssClass += " drop-target full-drop-target"),
        options.className = cssClass;
        var imageContainerClass,
        innerHTML = "";
        options.enableContentWrapper && (innerHTML += '<div class="' + options.contentWrapperClass + '">'),
        fieldMap.ChannelDisabledCheckbox && (options.channelCheckbox = '<label data-action="togglechanneldisabled" class="itemAction listItem-emby-checkbox-label emby-checkbox-label secondaryText"><input class="emby-checkbox emby-checkbox-notext" is="emby-checkbox" type="checkbox" data-classes="true" /><span class="checkboxLabel listItem-checkboxLabel"></span></label>', innerHTML += options.channelCheckbox),
        !1 !== options.image && (options.shape = imageLoader.getShape(items, options) || "square", options.aspectInfo = imageLoader.getAspectFromShape(options.shape, options), imageContainerClass = "listItemImageContainer", options.isLargeStyle && (imageContainerClass += " listItemImageContainer-large", layoutManager.tv && (imageContainerClass += " listItemImageContainer-large-tv")), options.clickEntireItem || (imageContainerClass += " itemAction"), imageContainerClass += " listItemImageContainer-" + options.shape, innerHTML += '<div class="' + (options.imageContainerClass = imageContainerClass) + '"></div>'),
        options.listItemBodyClassName = "listItemBody",
        options.clickEntireItem || (options.listItemBodyClassName += " itemAction"),
        !1 === options.image && (options.listItemBodyClassName += " listItemBody-noleftpadding"),
        !1 === options.verticalPadding && (options.listItemBodyClassName += " listItemBody-noverticalpadding"),
        options.code && (options.listItemBodyClassName += " listItemBody-code"),
        options.dragHandle && (options.listItemBodyClassName += " listItemBody-tall");
        options.iconClass ? options.iconClass += " listItemIcon md-icon" : options.iconClass = "listItemIcon md-icon",
        innerHTML += "<" + options.listItemBodyTagName + ' class="' + options.listItemBodyClassName + '">';
        var textlines = [];
        fieldMap.DateModified && textlines.push("&nbsp;"),
        fieldMap.ChannelNameAndNumber && textlines.push("&nbsp;"),
        fieldMap.MappedChannelInfo && textlines.push("&nbsp;"),
        fieldMap.ChannelNumber && textlines.push("&nbsp;"),
        options.showDateCreated && textlines.push("&nbsp;"),
        options.showDate && textlines.push("&nbsp;"),
        options.showShortOverview && textlines.push("&nbsp;"),
        options.showProgramDateTime && textlines.push("&nbsp;"),
        options.showChannel && textlines.push("&nbsp;"),
        options.showLogLine && textlines.push("&nbsp;"),
        options.showAccessToken && textlines.push("&nbsp;"),
        options.showParentTitle && textlines.push("&nbsp;"),
        fieldMap.ChannelNameAndNumber || textlines.push("&nbsp;"),
        textlines.length < 1 && textlines.push("&nbsp;"),
        textlines.length < 2 && textlines.push("&nbsp;"),
        innerHTML += getTextLinesHtml(textlines, options.isLargeStyle),
        options.enableOverview && (!1 !== options.mediaInfo && (options.enableSideMediaInfo || options.mediaInfoWithTitle || (innerHTML += '<div class="listItemMediaInfo listItemBodyText listItemBodyText-secondary listItemBodyText-nowrap"></div>')), options.topOverviewClassName = "listItem-overview listItemBodyText listItemBodyText-secondary", options.overviewLineClamp && (options.topOverviewClassName += " listItemOverview-clamped"), innerHTML += '<div class="' + options.topOverviewClassName + '"></div>'),
        innerHTML += "</" + options.listItemBodyTagName + ">",
        options.dragHandle && (innerHTML += '<i class="listViewDragHandle dragHandle md-icon listItemIcon listItemIcon-transparent">&#xE25D;</i>'),
        options.enableContentWrapper && (innerHTML += "</div>", options.enableOverview && (options.bottomOverviewClassName = "listItem-bottomoverview secondaryText", options.overviewLineClamp && (options.bottomOverviewClassName += " listItemOverview-clamped"), innerHTML += '<div class="' + options.bottomOverviewClassName + '">&nbsp;</div>'));
        var fixedAttributes = "";
        options.addTabIndex && (fixedAttributes += ' tabindex="0"'),
        options.draggable && (fixedAttributes += ' draggable="true"'),
        options.fixedAttributes = fixedAttributes.trim(),
        options.templateInnerHTML = innerHTML
    }
    function getListViewHtml(items, options) {
        setListOptions(items, options);
        for (var groupTitle = "", html = "", i = 0, length = items.length; i < length; i++) {
            var itemGroupTitle,
            item = items[i];
            !options.showIndex || (itemGroupTitle = function (item, options) {
                if ("disc" !== options.index)
                    return "";
                var parentIndexNumber = item.ParentIndexNumber;
                return 1 === parentIndexNumber || null == parentIndexNumber ? "" : globalize.translate("ValueDiscNumber", parentIndexNumber)
            }
                (item, options)) !== groupTitle && (html += 0 === i ? '<h2 class="listGroupHeader listGroupHeader-first">' : '<h2 class="listGroupHeader">', html += itemGroupTitle, html += "</h2>", groupTitle = itemGroupTitle),
            html += getListItemHtml(item, i, options)
        }
        return html
    }
    return {
        getListViewHtml: getListViewHtml,
        getItemsHtml: getListViewHtml,
        setListOptions: setListOptions,
        getItemParts: function (item, index, options) {
            return options.listItemParts = !0,
            getListItemHtml(item, index, options)
        },
        buildItems: function (items, options) {
            var itemsContainer = options.itemsContainer;
            if (document.body.contains(itemsContainer)) {
                var parentContainer = options.parentContainer;
                if (parentContainer) {
                    if (!items.length)
                        return void parentContainer.classList.add("hide");
                    parentContainer.classList.remove("hide")
                }
                var html = getListViewHtml(items, options);
                itemsContainer.innerHTML = html,
                itemsContainer.items = items,
                options.multiSelect && (itemsContainer.enableMultiSelect ? itemsContainer.enableMultiSelect(!0) : itemsContainer.setAttribute("data-multiselect", "true")),
                options.contextMenu && (itemsContainer.enableContextMenu ? itemsContainer.enableContextMenu(!0) : itemsContainer.setAttribute("data-contextmenu", "true")),
                html && imageLoader.lazyChildren(itemsContainer),
                options.autoFocus && focusManager.autoFocus(itemsContainer)
            }
        }
    }
});
