# ShareList

[![Build Status](https://api.travis-ci.com/reruin/sharelist.svg?branch=master)](https://travis-ci.com/reruin/sharelist)

## Introduction
ShareList is an easy-to-use netdisk tool which supports that quickly mount GoogleDrive and OneDrive, and extends functions with plugins.

## Documentation
Check out [docs](https://reruin.github.io/sharelist/#/en/).

## License
[Apache-2](http://www.apache.org/licenses/LICENSE-2.0)
Copyright (c) 2018-present, Reruin